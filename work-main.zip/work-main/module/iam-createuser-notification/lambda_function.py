import json
import boto3
import os
import logging
import pytz
from datetime import datetime

logger = logging.getLogger()
logger.setLevel(os.getenv('LOGGER_SHOW', 'INFO'))

def lambda_handler(event, context):
    # Get the event details
    detail = event['detail']
    
    # Extract user details
    user_name = detail['requestParameters']['userName']
    timestamp = event['time']
    creator = detail['userIdentity']['arn']
    source_ip = detail.get('sourceIPAddress', 'N/A')

    utc_time = datetime.strptime(timestamp, '%Y-%m-%dT%H:%M:%SZ').replace(tzinfo=pytz.UTC)
    tokyo_timezone = pytz.timezone('Asia/Tokyo')
    tokyo_time = utc_time.astimezone(tokyo_timezone)
    timestamp = tokyo_time.strftime('%Y-%m-%dT%H:%M:%S')
    
    # Create message
    message = f"""
    新しいIAMユーザーが作成されました:
    
    - 作成されたユーザー名: {user_name}
    - 作成者: {creator}
    - 作成日時: {timestamp}
    - 発信元IP: {source_ip}
    - AWSアカウントID: {event['account']}
    """
    
    logger.info(message)

    # Send notification
    sns = boto3.client('sns')
    sns.publish(
        TopicArn=os.environ['SNS_TOPIC_ARN'],
        Message=message,
        Subject='IAMユーザー作成通知'
    )
    
    return {
        'statusCode': 200,
        'body': json.dumps('Notification sent successfully')
    }
